class ReportAgent:
    def generate(self, alerts, analysis):
        report = f'''
📊 AI 自动分析报告

🔔 异常检测：
{chr(10).join(alerts) if alerts else "无明显异常"}

🧠 深度分析：
{analysis}
'''
        return report
