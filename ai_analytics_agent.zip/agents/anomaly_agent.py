class AnomalyAgent:
    def detect(self, df):
        alerts = []

        for channel in df['channel'].unique():
            sub = df[df['channel'] == channel].sort_values("date")

            if len(sub) < 2:
                continue

            latest = sub.iloc[-1]
            prev = sub.iloc[-2]

            if latest['cvr'] < prev['cvr'] * 0.7:
                alerts.append(f"{channel} 转化率下降明显")

            if latest['cpa'] > prev['cpa'] * 1.3:
                alerts.append(f"{channel} 获客成本上升")

        return alerts
