from utils.llm import ask_llm

class AnalysisAgent:
    def analyze(self, df, alerts):
        summary = df.groupby("channel").agg({
            "impressions": "sum",
            "clicks": "sum",
            "conversions": "sum",
            "cost": "sum"
        }).to_dict()

        prompt = f'''
你是一个资深数据分析师。

当前数据摘要：
{summary}

异常情况：
{alerts}

请分析：
1. 问题原因
2. 可能影响
3. 优化建议

输出要结构化、专业。
'''
        return ask_llm(prompt)
