import pandas as pd

class DataAgent:
    def load_data(self, path: str):
        df = pd.read_csv(path)
        df['ctr'] = df['clicks'] / df['impressions']
        df['cvr'] = df['conversions'] / df['clicks']
        df['cpa'] = df['cost'] / df['conversions']
        return df
