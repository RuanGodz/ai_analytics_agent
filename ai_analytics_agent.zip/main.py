from agents.data_agent import DataAgent
from agents.anomaly_agent import AnomalyAgent
from agents.analysis_agent import AnalysisAgent
from agents.report_agent import ReportAgent

def run():
    data_agent = DataAgent()
    anomaly_agent = AnomalyAgent()
    analysis_agent = AnalysisAgent()
    report_agent = ReportAgent()

    df = data_agent.load_data("data/sample_data.csv")

    alerts = anomaly_agent.detect(df)

    analysis = analysis_agent.analyze(df, alerts)

    report = report_agent.generate(alerts, analysis)

    print(report)


if __name__ == "__main__":
    run()
